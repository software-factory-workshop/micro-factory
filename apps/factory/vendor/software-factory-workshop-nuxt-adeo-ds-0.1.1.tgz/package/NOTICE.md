# Third-party sources

ADEO colour, size, radius and shadow values are adapted from Mozaic Design System, ADEO, revision `276fb7794ea4925d61bcbaa67838f1ddabff40f5`.

The source repository's Apache License 2.0 is preserved in `licenses/MOZAIC-LICENSE`. The upstream tokens package separately declares ISC in its metadata; this package retains the supplied repository license without resolving that discrepancy. Generated CSS and JSON include endpoint aliases. Components and theme adaptations are not official Mozaic releases.

Roboto, Nuxt UI and Lucide retain their licenses in their dependency packages. ADEO names and marks remain the property of their respective owners.
