# ADEO Nuxt UI

An ADEO-only Nuxt 4 layer: Nuxt UI 4, Mozaic ADEO colours, locally served Roboto fonts and 22 composed ADEO components. The catalogue is not included.

## Install

Requires Node 22.19+ or 24.11+ (Node 24 recommended), Nuxt 4.5.2+ within Nuxt 4, and Vue 3.5+.

This is a private GitHub package. Your GitHub account needs access to the package and a personal access token (classic) with `read:packages`. Authorize the token for your organization if SSO requires it.

Add this scope to your project's `.npmrc` (safe to commit):

```ini
@software-factory-workshop:registry=https://npm.pkg.github.com
```

Authenticate interactively; use your GitHub username and the token as the password:

```sh
npm login --scope=@software-factory-workshop --auth-type=legacy --registry=https://npm.pkg.github.com
npm install @software-factory-workshop/nuxt-adeo-ds
```

```ts
// nuxt.config.ts
export default defineNuxtConfig({
  extends: ['@software-factory-workshop/nuxt-adeo-ds']
})
```

```vue
<!-- app/app.vue -->
<template>
  <UApp>
    <AdeoPageHeader title="Your workspace" />
    <UButton icon="i-lucide-plus">New project</UButton>
  </UApp>
</template>
```

No separate CSS imports, fonts setup or component registration is needed. Use Nuxt UI's `U*` components with their upstream APIs and the ADEO components in [COMPONENTS.md](./COMPONENTS.md). Override theme values in your own `app/app.config.ts`. Do not also register `@nuxt/ui` in the consuming app's modules.

## CI installation

For another GitHub repository, grant that repository read access under this package's **Manage Actions access** settings. Use `actions/setup-node` with `registry-url: https://npm.pkg.github.com` and `scope: '@software-factory-workshop'`, grant `packages: read`, and run `npm ci` with `NODE_AUTH_TOKEN: ${{ secrets.GITHUB_TOKEN }}`.

Outside GitHub Actions, provide a classic token with `read:packages` as `NODE_AUTH_TOKEN` and add `//npm.pkg.github.com/:_authToken=${NODE_AUTH_TOKEN}` to the CI npm configuration. Never commit the token itself.

## Versions

Use your lockfile for reproducible installs. Upgrade with `npm install @software-factory-workshop/nuxt-adeo-ds@<version>`. See the repository's RELEASE.md for the publishing workflow and NOTICE.md for attribution.
