/** Client-side selection checks. Servers must independently validate uploaded content. */
export function fileSelectionError(
  files: File[],
  accept: string,
  maxBytes: number,
  maxFiles: number,
): string | undefined {
  if (files.length > maxFiles) return `Choose at most ${maxFiles} files.`;
  const types = accept
    .toLowerCase()
    .split(",")
    .map((type) => type.trim())
    .filter(Boolean);
  for (const file of files) {
    if (file.size > maxBytes)
      return `${file.name} exceeds the ${Math.round(maxBytes / 1024 / 1024)} MB limit.`;
    const allowed =
      !types.length ||
      types.some(
        (type) =>
          type === "*/*" ||
          type === "*" ||
          (type.startsWith(".")
            ? file.name.toLowerCase().endsWith(type)
            : type.endsWith("/*")
              ? file.type.toLowerCase().startsWith(type.slice(0, -1))
              : file.type.toLowerCase() === type),
      );
    if (!allowed) return `${file.name} is not an accepted file type.`;
  }
}
