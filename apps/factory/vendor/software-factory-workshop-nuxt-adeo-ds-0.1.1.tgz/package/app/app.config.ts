export default defineAppConfig({
  ui: {
    colors: {
      primary: "adeo",
      secondary: "adeo-purple",
      neutral: "adeo-grey",
      success: "adeo-success",
      info: "adeo-info",
      warning: "adeo-warning",
      error: "adeo-danger",
    },
    button: {
      slots: {
        base: "font-semibold cursor-pointer disabled:cursor-not-allowed",
      },
      compoundVariants: [
        {
          color: "primary",
          variant: "solid",
          class:
            "hover:bg-adeo-700 active:bg-adeo-800 dark:hover:bg-adeo-200 dark:active:bg-adeo-100",
        },
      ],
      defaultVariants: { size: "md" },
    },
    input: { slots: { base: "ring-adeo-grey-500" } },
    select: { slots: { base: "ring-adeo-grey-500" } },
    textarea: { slots: { base: "ring-adeo-grey-500" } },
    table: {
      slots: {
        th: "bg-adeo-purple-100 text-adeo-purple-700 font-semibold",
        tr: "hover:bg-adeo-blue-100/40",
      },
    },
  },
});
