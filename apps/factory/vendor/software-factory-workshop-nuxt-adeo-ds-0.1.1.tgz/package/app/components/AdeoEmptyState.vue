<script setup lang="ts">
withDefaults(
  defineProps<{ title: string; description?: string; icon?: string }>(),
  { icon: "i-lucide-inbox" },
);
</script>

<template>
  <div
    class="flex flex-col items-center rounded-lg border border-dashed border-accented px-6 py-12 text-center"
  >
    <span
      class="mb-4 flex size-12 items-center justify-center rounded-full bg-elevated"
      ><UIcon :name="icon" class="size-6 text-muted"
    /></span>
    <h3 class="font-bold text-highlighted">{{ title }}</h3>
    <p v-if="description" class="mt-2 max-w-sm text-sm leading-6 text-muted">
      {{ description }}
    </p>
    <div v-if="$slots.default" class="mt-5"><slot /></div>
  </div>
</template>
