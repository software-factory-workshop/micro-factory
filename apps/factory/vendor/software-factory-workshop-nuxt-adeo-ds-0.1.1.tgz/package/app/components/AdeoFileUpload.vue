<script setup lang="ts">
import { fileSelectionError } from "../utils/files";
const props = withDefaults(
  defineProps<{
    label?: string;
    accept?: string;
    maxBytes?: number;
    maxFiles?: number;
    disabled?: boolean;
  }>(),
  {
    label: "Choose files or drag them here",
    accept: "*",
    maxBytes: 5 * 1024 * 1024,
    maxFiles: 5,
  },
);
const files = defineModel<File[]>({ default: () => [] });
const emit = defineEmits<{ reject: [message: string] }>();
const error = ref<string>();
const id = useId();
function update(selection: File[] | null | undefined) {
  const next = selection ?? [];
  error.value = fileSelectionError(
    next,
    props.accept,
    props.maxBytes,
    props.maxFiles,
  );
  if (error.value) emit("reject", error.value);
  else files.value = next;
}
</script>
<template>
  <div>
    <UFileUpload
      :model-value="files"
      multiple
      :label="label"
      :accept="accept"
      :disabled="disabled"
      :aria-describedby="error ? id : undefined"
      :aria-invalid="!!error"
      :description="`Up to ${maxFiles} files, ${Math.round(maxBytes / 1024 / 1024)} MB each`"
      @update:model-value="update"
    />
    <p v-if="error" :id="id" role="alert" class="mt-2 text-sm text-error">
      {{ error }}
    </p>
  </div>
</template>
