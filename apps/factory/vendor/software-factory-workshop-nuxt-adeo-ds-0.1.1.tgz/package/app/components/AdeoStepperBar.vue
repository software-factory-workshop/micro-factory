<script setup lang="ts">
defineProps<{
  step: number;
  total: number;
  busy?: boolean;
  disabled?: boolean;
  sticky?: boolean;
}>();
const emit = defineEmits<{ previous: []; next: []; cancel: [] }>();
</script>
<template>
  <AdeoActionBar
    :status="`Step ${step + 1} of ${total}`"
    :busy="busy"
    :sticky="sticky"
    ><UButton
      color="neutral"
      variant="ghost"
      :disabled="busy"
      @click="emit('cancel')"
      >Cancel</UButton
    ><UButton
      variant="outline"
      :disabled="step <= 0 || busy"
      @click="emit('previous')"
      >Previous</UButton
    ><UButton :loading="busy" :disabled="disabled" @click="emit('next')">{{
      step >= total - 1 ? "Finish" : "Next"
    }}</UButton></AdeoActionBar
  >
</template>
