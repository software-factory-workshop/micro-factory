<script setup lang="ts">
withDefaults(
  defineProps<{ label?: string; readonly?: boolean; disabled?: boolean }>(),
  { label: "Rating" },
);
const value = defineModel<number>({ default: 0 });
const id = useId();
const clamped = computed(() => Math.max(0, Math.min(5, value.value)));
</script>
<template>
  <div
    v-if="readonly"
    role="img"
    :aria-label="`${label}: ${clamped} out of 5`"
    class="inline-flex gap-1"
  >
    <span v-for="star in 5" :key="star" class="relative inline-flex text-muted"
      ><svg viewBox="0 0 24 24" class="size-6" aria-hidden="true">
        <path
          d="M12 2 15 8.5 22 9.5 17 14.5 18.2 22 12 18.5 5.8 22 7 14.5 2 9.5 9 8.5Z"
          fill="none"
          stroke="currentColor"
        /></svg
      ><span
        class="absolute inset-0 overflow-hidden text-primary"
        :style="{
          width: `${Math.max(0, Math.min(1, clamped - star + 1)) * 100}%`,
        }"
        ><svg viewBox="0 0 24 24" class="size-6 shrink-0" aria-hidden="true">
          <path
            d="M12 2 15 8.5 22 9.5 17 14.5 18.2 22 12 18.5 5.8 22 7 14.5 2 9.5 9 8.5Z"
            fill="currentColor"
            stroke="currentColor"
          /></svg></span></span
    ><span class="ml-2 text-sm">{{ clamped }}/5</span>
  </div>
  <fieldset v-else :disabled="disabled">
    <legend class="mb-2 text-sm font-medium">{{ label }}</legend>
    <div class="flex flex-wrap items-center gap-2">
      <label
        v-for="star in 5"
        :key="star"
        class="relative cursor-pointer rounded p-1 has-[:focus-visible]:outline-2 has-[:focus-visible]:outline-primary"
        :class="{ 'opacity-50 cursor-not-allowed': disabled }"
        ><input
          v-model="value"
          :value="star"
          type="radio"
          :name="id"
          :aria-label="`${star} out of 5`"
          class="sr-only" /><svg
          viewBox="0 0 24 24"
          class="size-6"
          :class="star <= clamped ? 'text-primary' : 'text-muted'"
          aria-hidden="true"
        >
          <path
            d="M12 2 15 8.5 22 9.5 17 14.5 18.2 22 12 18.5 5.8 22 7 14.5 2 9.5 9 8.5Z"
            :fill="star <= clamped ? 'currentColor' : 'none'"
            stroke="currentColor"
          /></svg></label
      ><UButton
        size="xs"
        color="neutral"
        variant="ghost"
        :disabled="disabled || value === 0"
        aria-label="Clear rating"
        @click="value = 0"
        >Clear</UButton
      ><output class="text-sm" aria-live="polite">{{ clamped }}/5</output>
    </div>
  </fieldset>
</template>
