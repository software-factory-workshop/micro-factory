<script setup lang="ts">
defineOptions({ inheritAttrs: false });
defineProps<{ disabled?: boolean }>();
const value = defineModel<string>({ default: "" });
const visible = ref(false);
</script>
<template>
  <UInput
    v-model="value"
    v-bind="$attrs"
    :disabled="disabled"
    :type="visible ? 'text' : 'password'"
    :ui="{ trailing: 'pe-1', base: 'pe-16' }"
    ><template #trailing
      ><UButton
        :disabled="disabled"
        color="neutral"
        variant="link"
        size="xs"
        :aria-pressed="visible"
        :aria-label="visible ? 'Hide password' : 'Show password'"
        @click="visible = !visible"
        >{{ visible ? "Hide" : "Show" }}</UButton
      ></template
    ></UInput
  >
</template>
