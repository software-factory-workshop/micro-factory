<script setup lang="ts">
defineProps<{ items: string[]; disabled?: boolean; compact?: boolean }>();
const step = defineModel<number>({ default: 0 });
</script>
<template>
  <nav aria-label="Progress">
    <p v-if="compact" class="mb-3 text-sm text-muted">
      Step {{ step + 1 }} of {{ items.length }} · {{ items[step] }}
    </p>
    <ol class="flex flex-wrap gap-3">
      <li v-for="(item, index) in items" :key="item" class="min-w-0 flex-1">
        <button
          type="button"
          class="flex w-full items-center gap-2 rounded-md border p-3 text-left text-sm disabled:cursor-not-allowed"
          :class="
            index === step
              ? 'border-primary bg-adeo-100 text-adeo-800'
              : 'border-default text-muted'
          "
          :aria-current="index === step ? 'step' : undefined"
          :disabled="disabled || index > step"
          @click="step = index"
        >
          <UIcon
            v-if="index < step"
            name="i-lucide-check"
            class="shrink-0"
          /><span v-else class="shrink-0">{{ index + 1 }}</span
          ><span v-if="!compact || index === step">{{ item }}</span
          ><span v-else class="sr-only">{{ item }}</span>
        </button>
      </li>
    </ol>
  </nav>
</template>
