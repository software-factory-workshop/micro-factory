<script setup lang="ts">
export interface PhoneCountry {
  label: string;
  value: string;
  prefix: string;
}
defineOptions({ inheritAttrs: false });
withDefaults(
  defineProps<{ disabled?: boolean; countries?: PhoneCountry[] }>(),
  {
    countries: () => [
      { label: "France (+33)", value: "FR", prefix: "+33" },
      { label: "United Kingdom (+44)", value: "GB", prefix: "+44" },
      { label: "Germany (+49)", value: "DE", prefix: "+49" },
      { label: "Spain (+34)", value: "ES", prefix: "+34" },
      { label: "Italy (+39)", value: "IT", prefix: "+39" },
      { label: "Poland (+48)", value: "PL", prefix: "+48" },
      { label: "Portugal (+351)", value: "PT", prefix: "+351" },
      { label: "Brazil (+55)", value: "BR", prefix: "+55" },
    ],
  },
);
const countryId = useId();
const number = defineModel<string>({ default: "" });
const country = defineModel<string>("country", { default: "FR" });
</script>
<template>
  <div class="flex flex-wrap gap-2">
    <USelect
      :id="countryId"
      v-model="country"
      :items="countries"
      :disabled="disabled"
      aria-label="Phone country and calling code"
      class="w-full sm:w-48"
    /><UInput
      v-model="number"
      v-bind="$attrs"
      type="tel"
      autocomplete="tel-national"
      :disabled="disabled"
      class="min-w-0 flex-1"
    />
  </div>
</template>
