<script setup lang="ts">
import type { NavigationMenuItem } from "@nuxt/ui";
defineProps<{ title: string; items: NavigationMenuItem[] }>();
</script>
<template>
  <aside class="rounded-lg bg-adeo-blue-900 p-5 text-white">
    <div class="mb-6 font-bold">
      <slot name="header">{{ title }}</slot>
    </div>
    <UNavigationMenu
      :items="items"
      orientation="vertical"
      :aria-label="title"
      :ui="{
        link: 'text-white hover:text-white hover:bg-adeo-blue-700',
        linkLeadingIcon: 'text-adeo-200',
        linkLabel: 'text-white',
      }"
    />
    <div
      v-if="$slots.footer"
      class="mt-8 border-t border-adeo-blue-600 pt-4 text-sm text-adeo-blue-200"
    >
      <slot name="footer" />
    </div>
  </aside>
</template>
