<script setup lang="ts">
withDefaults(defineProps<{ level?: 1 | 2 | 3 | 4 | 5 | 6 }>(), { level: 2 });
</script>
<template>
  <component
    :is="`h${level}`"
    class="font-bold tracking-tight text-highlighted"
    :class="{
      'text-3xl sm:text-4xl': level === 1,
      'text-2xl': level === 2,
      'text-xl': level === 3,
      'text-lg': level === 4,
      'text-base': level >= 5,
    }"
    ><slot
  /></component>
</template>
