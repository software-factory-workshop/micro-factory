<script setup lang="ts">
withDefaults(
  defineProps<{
    loading?: boolean;
    overlay?: boolean;
    label?: string;
    size?: "sm" | "md" | "lg";
  }>(),
  { loading: true, overlay: false, label: "Loading", size: "md" },
);
</script>
<template>
  <div :class="overlay ? 'relative min-h-24' : ''" :aria-busy="loading">
    <div v-if="$slots.default" :inert="loading && overlay ? true : undefined">
      <slot />
    </div>
    <div
      v-if="loading"
      role="status"
      class="flex items-center justify-center gap-3 text-primary"
      :class="
        overlay ? 'absolute inset-0 z-10 rounded-lg bg-default/90' : 'py-4'
      "
    >
      <UIcon
        name="i-lucide-loader-circle"
        class="animate-spin"
        :class="{
          'size-4': size === 'sm',
          'size-6': size === 'md',
          'size-9': size === 'lg',
        }"
      /><span class="text-sm">{{ label }}</span>
    </div>
  </div>
</template>
