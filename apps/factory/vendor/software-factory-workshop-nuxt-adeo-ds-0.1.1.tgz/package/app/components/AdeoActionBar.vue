<script setup lang="ts">
withDefaults(
  defineProps<{ status?: string; busy?: boolean; sticky?: boolean }>(),
  { sticky: false },
);
</script>
<template>
  <div
    class="flex flex-wrap items-center justify-between gap-4 border-t border-default bg-default p-4"
    :class="{ 'sticky bottom-0 z-10': sticky }"
    :aria-busy="busy"
  >
    <p role="status" class="flex items-center gap-2 text-sm text-muted">
      <UIcon v-if="busy" name="i-lucide-loader-circle" class="animate-spin" />{{
        status
      }}<slot name="status" />
    </p>
    <div class="flex flex-wrap gap-2"><slot /></div>
  </div>
</template>
