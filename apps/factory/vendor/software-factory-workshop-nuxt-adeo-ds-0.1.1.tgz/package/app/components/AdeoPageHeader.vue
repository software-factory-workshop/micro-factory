<script setup lang="ts">
withDefaults(
  defineProps<{
    title: string;
    description?: string;
    eyebrow?: string;
    level?: 1 | 2;
  }>(),
  { level: 1 },
);
</script>

<template>
  <header class="flex flex-wrap items-end justify-between gap-6">
    <div class="max-w-2xl">
      <p
        v-if="eyebrow"
        class="mb-3 text-xs font-bold uppercase tracking-[0.16em] text-primary"
      >
        {{ eyebrow }}
      </p>
      <component
        :is="`h${level}`"
        class="text-3xl font-bold tracking-tight text-highlighted sm:text-4xl"
      >
        {{ title }}
      </component>
      <p v-if="description" class="mt-4 text-base leading-7 text-muted">
        {{ description }}
      </p>
    </div>
    <div v-if="$slots.actions" class="flex items-center gap-3">
      <slot name="actions" />
    </div>
  </header>
</template>
