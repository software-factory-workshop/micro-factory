<script setup lang="ts">
defineProps<{
  label: string;
  to?: string;
  selectable?: boolean;
  removable?: boolean;
  disabled?: boolean;
}>();
const selected = defineModel<boolean>({ default: false });
const emit = defineEmits<{ remove: [] }>();
</script>
<template>
  <UButton
    v-if="to"
    :to="to"
    :disabled="disabled"
    size="sm"
    color="neutral"
    variant="subtle"
    >{{ label }}</UButton
  ><UButton
    v-else-if="selectable"
    :disabled="disabled"
    size="sm"
    :color="selected ? 'primary' : 'neutral'"
    variant="subtle"
    :aria-pressed="selected"
    @click="selected = !selected"
    >{{ label }}</UButton
  ><span
    v-else
    class="inline-flex items-center gap-1 rounded-md bg-elevated px-2 py-1 text-sm text-default"
    >{{ label
    }}<UButton
      v-if="removable"
      icon="i-lucide-x"
      color="neutral"
      variant="ghost"
      size="xs"
      :disabled="disabled"
      :aria-label="`Remove ${label}`"
      @click="emit('remove')"
  /></span>
</template>
