<script setup lang="ts">
withDefaults(
  defineProps<{
    label: string;
    value: string | number;
    detail?: string;
    icon?: string;
    color?: "neutral" | "info" | "success" | "warning" | "error";
    evolution?: string;
    direction?: "up" | "down" | "flat";
    size?: "sm" | "md" | "lg";
  }>(),
  { color: "neutral", size: "md" },
);
const tones = {
  neutral: "bg-elevated text-highlighted",
  info: "bg-adeo-info-100 text-adeo-info-800",
  success: "bg-adeo-success-100 text-adeo-success-800",
  warning: "bg-adeo-warning-100 text-adeo-warning-800",
  error: "bg-adeo-danger-100 text-adeo-danger-800",
};
const trendIcons = {
  up: "i-lucide-trending-up",
  down: "i-lucide-trending-down",
  flat: "i-lucide-minus",
};
</script>
<template>
  <div class="overflow-hidden rounded-lg border border-default">
    <div
      :class="[
        tones[color],
        size === 'sm' ? 'p-3' : size === 'lg' ? 'p-7' : 'p-5',
      ]"
    >
      <div class="flex items-center justify-between gap-4">
        <p class="text-sm">{{ label }}</p>
        <UIcon v-if="icon" :name="icon" class="size-5" />
      </div>
      <p
        class="mt-3 font-bold tracking-tight"
        :class="
          size === 'sm' ? 'text-2xl' : size === 'lg' ? 'text-4xl' : 'text-3xl'
        "
      >
        {{ value }}
      </p>
      <p v-if="detail" class="mt-2 text-xs">{{ detail }}</p>
    </div>
    <p
      v-if="evolution"
      class="flex items-center gap-2 px-5 py-3 text-sm text-muted"
    >
      <UIcon v-if="direction" :name="trendIcons[direction]" /><span>{{
        evolution
      }}</span>
    </p>
  </div>
</template>
