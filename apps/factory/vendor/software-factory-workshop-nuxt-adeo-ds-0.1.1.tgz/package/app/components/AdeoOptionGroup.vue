<script setup lang="ts">
export interface AdeoOption {
  value: string;
  label: string;
  description?: string;
  icon?: string;
  disabled?: boolean;
}
withDefaults(
  defineProps<{
    label: string;
    items: AdeoOption[];
    multiple?: boolean;
    disabled?: boolean;
    variant?: "button" | "card";
    name?: string;
  }>(),
  { variant: "button" },
);
const value = defineModel<string | string[]>({ default: "" });
const id = useId();
function selected(option: string) {
  return Array.isArray(value.value)
    ? value.value.includes(option)
    : value.value === option;
}
function update(option: string, multiple: boolean) {
  if (!multiple) {
    value.value = option;
    return;
  }
  const current = Array.isArray(value.value) ? value.value : [];
  value.value = current.includes(option)
    ? current.filter((item) => item !== option)
    : [...current, option];
}
</script>
<template>
  <fieldset :disabled="disabled">
    <legend class="mb-3 text-sm font-medium text-highlighted">
      {{ label }}
    </legend>
    <div class="flex flex-wrap gap-3">
      <label
        v-for="item in items"
        :key="item.value"
        class="relative flex min-w-0 items-start gap-3 rounded-md border p-3 text-sm has-[:focus-visible]:outline-2 has-[:focus-visible]:outline-primary"
        :class="[
          selected(item.value)
            ? 'border-primary bg-adeo-100 text-adeo-900'
            : 'border-accented',
          disabled || item.disabled
            ? 'cursor-not-allowed opacity-60'
            : 'cursor-pointer',
          variant === 'card' ? 'flex-1 basis-40 p-4' : '',
        ]"
        ><input
          :type="multiple ? 'checkbox' : 'radio'"
          :name="name ?? id"
          :value="item.value"
          :checked="selected(item.value)"
          :disabled="disabled || item.disabled"
          class="mt-0.5 size-4 shrink-0 accent-[var(--ui-primary)]"
          @change="update(item.value, !!multiple)"
        /><span
          ><UIcon
            v-if="item.icon && variant === 'card'"
            :name="item.icon"
            class="mb-2 size-6"
          /><span class="block font-medium">{{ item.label }}</span
          ><span
            v-if="item.description && variant === 'card'"
            class="mt-2 block leading-6"
            >{{ item.description }}</span
          ></span
        ></label
      >
    </div>
  </fieldset>
</template>
