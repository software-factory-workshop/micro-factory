<script setup lang="ts">
withDefaults(
  defineProps<{
    label: string;
    items: { label: string; value: string; icon?: string }[];
    disabled?: boolean;
    size?: "sm" | "md";
  }>(),
  { size: "md" },
);
const value = defineModel<string>();
const id = useId();
</script>
<template>
  <fieldset
    :disabled="disabled"
    class="inline-flex max-w-full flex-wrap gap-1 rounded-md border border-accented bg-elevated p-1"
  >
    <legend class="sr-only">{{ label }}</legend>
    <label
      v-for="item in items"
      :key="item.value"
      class="relative flex items-center gap-2 rounded-sm px-3 text-sm font-medium has-[:focus-visible]:outline-2 has-[:focus-visible]:outline-primary"
      :class="[
        size === 'sm' ? 'min-h-8' : 'min-h-12',
        value === item.value ? 'bg-primary text-inverted' : 'text-muted',
        disabled ? 'cursor-not-allowed opacity-60' : 'cursor-pointer',
      ]"
      ><input
        v-model="value"
        type="radio"
        :name="id"
        :value="item.value"
        :aria-label="item.label"
        class="sr-only"
      /><UIcon v-if="item.icon" :name="item.icon" />{{ item.label }}</label
    >
  </fieldset>
</template>
