<script setup lang="ts">
import type { NavigationMenuItem } from "@nuxt/ui";
defineProps<{ items: NavigationMenuItem[]; label?: string }>();
</script>
<template>
  <UNavigationMenu
    :items="items"
    orientation="vertical"
    :aria-label="label ?? 'Section navigation'"
    class="w-full"
  />
</template>
