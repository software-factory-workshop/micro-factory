<script setup lang="ts">
withDefaults(
  defineProps<{ to: string; external?: boolean; disabled?: boolean }>(),
  { external: false, disabled: false },
);
</script>
<template>
  <span v-if="disabled" aria-disabled="true" class="text-muted"><slot /></span
  ><NuxtLink
    v-else
    :to="to"
    :external="external"
    :target="external ? '_blank' : undefined"
    :rel="external ? 'noopener noreferrer' : undefined"
    class="inline-flex items-center gap-1 text-primary underline underline-offset-4 hover:decoration-2"
    ><slot /><UIcon
      v-if="external"
      name="i-lucide-arrow-up-right"
      aria-label="Opens in a new tab"
  /></NuxtLink>
</template>
