<script setup lang="ts">
defineOptions({ inheritAttrs: false });
withDefaults(
  defineProps<{
    min?: number;
    max?: number;
    step?: number;
    disabled?: boolean;
  }>(),
  { min: 0, step: 1 },
);
const value = defineModel<number>({ default: 0 });
</script>
<template>
  <UInputNumber
    v-model="value"
    v-bind="$attrs"
    :min="min"
    :max="max"
    :step="step"
    :disabled="disabled"
  />
</template>
