<script setup lang="ts">
defineProps<{ title: string; description?: string; eyebrow?: string }>();
</script>
<template>
  <section
    class="relative overflow-hidden rounded-lg bg-adeo-blue-900 p-6 text-white sm:p-10"
  >
    <p
      v-if="eyebrow"
      class="mb-4 text-xs font-bold uppercase tracking-widest text-adeo-200"
    >
      {{ eyebrow }}
    </p>
    <h2 class="text-3xl font-bold tracking-tight sm:text-4xl">{{ title }}</h2>
    <p v-if="description" class="mt-4 max-w-xl leading-7 text-adeo-blue-200">
      {{ description }}
    </p>
    <div v-if="$slots.default" class="mt-6"><slot /></div>
    <div v-if="$slots.actions" class="mt-6 flex flex-wrap gap-3">
      <slot name="actions" />
    </div>
  </section>
</template>
