<script setup lang="ts">
defineOptions({ inheritAttrs: false });
withDefaults(
  defineProps<{
    type?: "date" | "month" | "week" | "time" | "datetime-local";
    disabled?: boolean;
  }>(),
  { type: "date" },
);
const value = defineModel<string>({ default: "" });
</script>
<template>
  <UInput v-model="value" v-bind="$attrs" :type="type" :disabled="disabled" />
</template>
