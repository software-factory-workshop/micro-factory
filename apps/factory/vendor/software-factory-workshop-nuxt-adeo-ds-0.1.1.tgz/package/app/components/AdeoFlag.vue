<script setup lang="ts">
withDefaults(
  defineProps<{
    label: string;
    color?: "primary" | "secondary" | "neutral" | "error";
    variant?: "solid" | "outline";
  }>(),
  { color: "primary", variant: "solid" },
);
</script>
<template>
  <UBadge
    :color="color"
    :variant="variant"
    class="rounded-none px-3 py-1 font-bold uppercase tracking-wide"
    >{{ label }}</UBadge
  >
</template>
