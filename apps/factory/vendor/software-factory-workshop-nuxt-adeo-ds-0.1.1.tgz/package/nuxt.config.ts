import { fileURLToPath } from "node:url";

export default defineNuxtConfig({
  modules: ["@nuxt/ui"],
  css: [fileURLToPath(new URL("./app/assets/css/main.css", import.meta.url))],
  ui: { fonts: false },
  colorMode: { preference: "light", fallback: "light" },
});
