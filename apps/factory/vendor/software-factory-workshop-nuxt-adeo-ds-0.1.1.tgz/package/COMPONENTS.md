# Reusable ADEO components

Extend `nuxt-adeo-ds/layer` and wrap your app in `UApp`. All components below are auto-imported. Vue `v-model` uses `modelValue` and `update:modelValue` unless a named model is specified. Normal HTML attributes are forwarded to the input in input wrappers.

## Forms and selection

| Component | Models | Props and behaviour |
| --- | --- | --- |
| `AdeoDatePicker` | string | `type`: date, month, week, time, datetime-local; `disabled`; forward `min`, `max`, `required`, `name`, `aria-label`. Native browser UI. |
| `AdeoPasswordInput` | string | `disabled`; forwards input attributes. Show/Hide button does not submit a form. Set `autocomplete` for your use case. |
| `AdeoPhoneInput` | string, `v-model:country` string | National number and ISO country code, separately. `countries`: `{ label, value, prefix }[]`; `disabled`. Defaults to France and eight country choices. No validation or E.164 conversion. |
| `AdeoQuantitySelector` | number | `min` default 0, `max`, `step` default 1, `disabled`. Uses Nuxt UI number input with keyboard and button controls. |
| `AdeoFileUpload` | File[] | `label`, `accept`, `maxBytes` default 5 MB, `maxFiles` default 5, `disabled`. Emits `reject(message)` and displays selection errors. Rejected selections preserve accepted files. No network upload. |
| `AdeoOptionGroup` | string for single, string[] for multiple | `label`, `items`: `{ value, label, description?, icon?, disabled? }[]`, `multiple`, `variant`: button/card, `disabled`, `name`. Uses native radio or checkbox semantics. |
| `AdeoSegmentedControl` | string | `label`, `items`: `{ label, value, icon? }[]`, `disabled`, `size`: sm/md. Connect the model to alternative views of the same content. |
| `AdeoRating` | number | `label`, `readonly`, `disabled`. Input supports integers 0–5; clear resets to 0. Read-only supports fractional values and exposes a textual rating. |

Use `UInputMenu` for autocomplete, `USelectMenu` for triggered searchable listboxes, and `UTextarea` for multi-line input. Their full Nuxt UI props and slots remain available.

File checks are a selection convenience, not a security boundary. Independently validate file bytes, type and size at your upload endpoint. `npm test` runs file-selection boundary tests using Node 24 or another Node release with native TypeScript stripping.

## Navigation and workflow

| Component | API |
| --- | --- |
| `AdeoActionBar` | `status`, `busy`, `sticky`; default action slot and optional `status` slot. Busy announces state; callers disable their action buttons. Sticky positioning is relative to its scroll container. |
| `AdeoStepperBar` | `step`: zero-based index, `total`, `busy`, `disabled`, `sticky`; emits `previous`, `next`, `cancel`. The last next button reads Finish. Parent validates before advancing. |
| `AdeoStepper` | number model: zero-based index; `items`: string[], `disabled`, `compact`. Only current and previous steps can be clicked. Parent advances after validation. Keep the model within the item range. |
| `AdeoBuiltInMenu` | `items`: Nuxt UI `NavigationMenuItem[]`, optional `label`; vertical section navigation. |
| `AdeoSidebar` | `title`, `items`: `NavigationMenuItem[]`; optional `header` and `footer` slots. Responsive placement belongs to the consuming app. |
| `AdeoLink` | `to`, `external`, `disabled`; default label slot. External links open in a new tab with a safe rel value. Disabled links render noninteractive text. |

Use `UDropdownMenu`, `USlideover`, `UPagination`, `UTooltip` and `UTabs` directly. Gallery examples connect pagination and segmented controls to real sample data and include a validated three-step flow.

## Content and feedback

| Component | API |
| --- | --- |
| `AdeoHeading` | `level`: 1–6, default 2; default text slot. |
| `AdeoHero` | `title`, `description`, `eyebrow`; default content and `actions` slots. Uses an h2; place it below the page's h1. |
| `AdeoPageHeader` | `title`, `description`, `eyebrow`, `level`: 1/2 default 1; `actions` slot. |
| `AdeoStatCard` | `label`, `value`, `detail`, `icon`; `color`: neutral/info/success/warning/error; `size`: sm/md/lg; `evolution` text and `direction`: up/down/flat. Status and direction are independent because increases are not always positive. |
| `AdeoFlag` | `label`; `color`: primary/secondary/neutral/error; `variant`: solid/outline. |
| `AdeoTag` | `label`, `to`, `selectable`, `removable`, `disabled`; boolean model for selection; emits `remove`. Use one mode at a time: link, selectable, removable, or plain text. |
| `AdeoLoader` | `loading` default true, `overlay`, `label`, `size`: sm/md/lg. Default slot is made inert under the active overlay. Uses an announced status. |
| `AdeoEmptyState` | `title`, `description`, `icon`; default action slot. |

Standard buttons, cards, badges, alerts, tables, progress bars and separators use their native Nuxt UI APIs with the ADEO theme. Theme mapping lives in `layer/app/app.config.ts` and `layer/app/assets/css/main.css`.
